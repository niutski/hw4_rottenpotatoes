require 'spec_helper'

describe Movie do
  describe 'searching TMDb by director' do
    it 'should call the find method with the director name' do 
      Movie.should_receive(:where).with(hash_including :director => 'Ridley Scott')
      Movie.find_by_director('Ridley Scott')
    end
    it 'should raise error given nil director' do
       lambda {
         Movie.find_by_director nil
       }.should raise_error(Movie::MissingDirectorError)
    end
    it 'should raise error given empty director' do
       lambda {
         Movie.find_by_director ''
       }.should raise_error(Movie::MissingDirectorError)
    end

  end
end
