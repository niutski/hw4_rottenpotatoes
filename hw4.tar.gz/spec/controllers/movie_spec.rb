require 'spec_helper'
describe MoviesController do
  describe 'searing for similar movies by director' do
    before :each do
      @fake_results = [mock('movie1'), mock('movie2')]
      @movie = Movie.new
      @movie.title = 'Pulp Fiction'
      @movie.director = 'Quentin Tarantino'
      Movie.stub(:find_by_id).and_return(@movie)
    end
    it 'should call the model method that performs the search by director' do
      Movie.should_receive(:find_by_id).with('1').and_return(@movie)
      Movie.should_receive(:find_by_director).with('Quentin Tarantino').and_return(@fake_results)
      get :similar, :id => 1
    end
    it 'should select the Find By Same Director view for rendering given director is set' do
      Movie.stub(:find_by_director).and_return(@fake_results)
      get :similar, :id => 1
      response.should render_template('similar')
    end
    it 'should return to home page give director is not set' do
      Movie.stub(:find_by_director).and_raise(Movie::MissingDirectorError.new)
      get :similar, :id => 1
      response.should redirect_to(movies_path)
    end
    it 'should flash warning given director is not set' do
      Movie.stub(:find_by_director).and_raise(Movie::MissingDirectorError.new)
      get :similar, :id => 1
      flash[:warning].should == "'Pulp Fiction' has no director info"
    end
    it 'should make the original movie available to the view' do
      get :similar, :id => 1
      assigns(:movie).should == @movie
    end
   
    it 'should make the results available to the view' do
      Movie.stub(:find_by_director).and_return(@fake_results)
      get :similar, :id => 1
      assigns(:results).should == @fake_results
    end
  end

  describe 'when creating a movie' do
    before :each do
      @movie_params = {"title" => 'Movie'}
      @movie = Movie.new :title => @movie_params["title"]
    end
    it 'should call the Movie#create method' do
      Movie.should_receive(:create!).with(@movie_params).and_return(@movie)
      post :create, :movie => @movie_params
    end
    it 'should flash the right message' do
      Movie.should_receive(:create!).and_return(@movie)
      post :create, :movie => @movie_params
      flash[:notice].should == "#{@movie.title} was successfully created."
    end
  end
  
  describe 'when sorting' do
    before :each do 
      @fake_results = [mock('movie1'), mock('movie2')]
    end
    it 'should sort by title when selecting title' do
      #Movie.should_receive(:find_all_by_rating).with([], hash_including(:order => :title))
      get :index, :sort => 'title'
       response.should redirect_to("/movies?&sort=title")
    end
    it 'should save sort into session' do
     get :index, :sort => 'title'
     session[:sort].should == 'title'
    end
    it 'should redirect with session values' do
      session[:sort] = 'title'
      get :index
      response.should redirect_to("/movies?&sort=title")
    end
    it 'should override session with param' do
      session[:sort] = 'title'
      get :index, :sort => 'release_date'
      session[:sort].should == 'release_date'     
    end
    it 'should redirect with saved ratings' do
      session[:ratings] = ["PG"]
      get :index
      # %5B and %5D are html-escaped []
      response.should redirect_to("/movies?ratings%5B%5D=PG")
    end
  end
  describe 'deleting movies' do
    before :each do
      @movie = Movie.new :title => 'Movie'
      Movie.should_receive(:find).and_return(@movie)
    end
    it 'should call the destroy method' do
      @movie.should_receive :destroy
      delete :destroy, :id => 1
    end
    it 'should flash' do
      delete :destroy, :id => 1
      flash[:notice].should == "Movie 'Movie' deleted."
    end
    it 'should redirect to the home page' do
      delete :destroy, :id => 1
      response.should redirect_to(movies_path)
    end
  end
  describe 'updating movie' do
    before :each do
      @movie = Movie.new :title => 'Movie'
      Movie.should_receive(:find).and_return(@movie)
    end
    it 'should redirect to the movie page' do
      put :update, :movie => @movie, :id => 1
      response.should redirect_to movie_path(@movie)
    end
    it 'should flash' do
      put :update, :movie => @movie, :id => 1
      flash[:notice].should == "#{@movie.title} was successfully updated."
    end
  end

  describe 'edit movie page' do
    it 'should find movie by id and make it available' do
      mock1 = mock('Movie')
      Movie.should_receive(:find).with('1').and_return(mock1)
      get :edit, :id => 1
      assigns[:movie].should == mock1
    end
  end
end
