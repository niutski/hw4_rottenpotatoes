Given /^the following movies exist:$/ do |table|
  # table is a Cucumber::Ast::Table
    table.hashes.each do |movie|
    m = Movie.new(:title => movie[:title], :rating => movie[:rating], :release_date => movie[:release_date], :director => movie[:director])
    m.save
  end
end

Then /^the director of "([^"]*)" should be "([^"]*)"$/ do |arg1, arg2|
  m = Movie.find_by_title(arg1)
  m.director.should == arg2 
end

